<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Valores numericos que alimentan los selects del sistema, agrupados por nombre (mangas, etc.).
     */
    public function up(): void
    {
        Schema::create('ajustes', function (Blueprint $table) {
            $table->id();
            $table->string('grupo')->index();
            $table->decimal('valor', 12, 2);
            $table->timestamps();

            $table->unique(['grupo', 'valor']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ajustes');
    }
};
